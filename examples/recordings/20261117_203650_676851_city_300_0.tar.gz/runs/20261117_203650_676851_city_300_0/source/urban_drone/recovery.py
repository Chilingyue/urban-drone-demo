"""Short, sensed clearance recovery when the current pose blocks inflated A*."""

import math
import numpy as np

from .planning import sample_path

EXECUTION_CLEARANCE = 0.75
RECOVERY_TRIGGER = 1.2
RECOVERY_TARGET = 1.6


def clearance_recovery(position, observation, prior, forward=None):
    """Move horizontally away from measured surfaces, preferring forward motion.

    This is a last resort: the mission only calls it after ordinary local
    candidates failed.  A*'s 1.1 m inflation can exclude an otherwise executable
    current pose.  This connector never clears occupied cells or lowers the
    0.75 m execution limit.  Every sample must be visible, clear of the public
    prior, and increase clearance from the measured surface until the normal
    planning margin returns.

    When ``forward`` is given, headings with a non-negative dot product are
    tried first, so clearance is regained without flying back along the route;
    backward headings remain available only when no forward or lateral
    connector is executable.
    """
    start = np.asarray(position, dtype=float)
    initial = float(observation.distances(start[None])[0])
    if not EXECUTION_CLEARANCE < initial < RECOVERY_TRIGGER:
        return None
    with observation.lock:
        _, index = observation.tree.query(start)
        away = start[:2]-observation.points[index,:2]
    headings = [np.array([math.cos(a), math.sin(a)]) for a in np.linspace(0,2*math.pi,24,endpoint=False)]
    if np.linalg.norm(away) > 1e-6:
        headings.insert(0,away/np.linalg.norm(away))
    direction = None
    if forward is not None:
        direction = np.asarray(forward[:2], dtype=float)
        length = float(np.linalg.norm(direction))
        direction = direction/length if length > 1e-9 else None
    if direction is None:
        groups = [headings]
    else:
        groups = [[h for h in headings if float(h @ direction) > -0.05],
                  [h for h in headings if float(h @ direction) <= -0.05]]
    for group in groups:
        best, best_score = None, float('inf')
        for heading in group:
            for distance in (.5,1.,1.5,2.,2.5):
                end=start+np.array([*heading,0])*distance
                path=sample_path([start,end],.08)
                measured=observation.distances(path)
                if (measured[-1] < RECOVERY_TARGET or
                        np.any(measured <= EXECUTION_CLEARANCE) or
                        np.any(np.diff(measured) < -.005)):
                    continue
                if not prior.safe(path,prior.execution_inflation):
                    continue
                if not prior.safe(end[None]):
                    continue
                if not observation.observed_free(path,margin=.4).all():
                    continue
                score=distance-.05*min(float(measured[-1]),2.)
                if score < best_score:
                    best,best_score=path,score
                break
        if best is not None:
            return best
    return None
